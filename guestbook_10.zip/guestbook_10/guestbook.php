<html>
<head>
<title>Harry's PHP Guestbook</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#FFFFFF" text="#000000">
<h2>Harry's PHP Guestbook 1.0</h2>
<ul>
  <li> <a href="guestbook.php?action=new">Add an entry</a></li>
  <li><a href="guestbook.php?action=view">Read Guestbook</a></li>
</ul>
<p> 
  <?php include("gbsrc.php"); ?>
</p>
<p>&nbsp;</p>
<hr noshade>
<div align="center"><b><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Copyright 
  by Harald Meyer <br>
  <a href="http://tools.harrym.nu" target="_blank">http://tools.harrym.nu</a></font></b></div>
<p>&nbsp;</p>
</body>
</html>
