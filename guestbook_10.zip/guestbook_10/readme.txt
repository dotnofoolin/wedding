/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
			PHP Guestbook 1.0 (Feb. 2002)
			by Harald Meyer (webmaster@harrym.nu) 
			Feel free to use it, but don't delete these lines. 
			PHP FXP is Freeware. 
			Based on another Guestbook.
			Please send me modified versions! 
			If you use it on your page, a link back to its homepage would
			be highly appreciated.
			Homepage: http://tools.harrym.nu/php_guestbook.php
 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */


***REQUIREMENTS
- PHP Webspace


***INSTALLATION
Upload the file on your webserver and chmod "gbook_data.php" to 777.


***Contact, Questions, Improvements
If you have any problems with the script, just post your question in my forum.

Harald Meyer
PHP-Guestbook Homepage: http://tools.harrym.nu/php_guestbook.php
Board: http://board.harrym.nu
Email: webmaster@harrym.nu